
# Sticky Notes App

## Run
pip install django
python manage.py migrate
python manage.py runserver

## Tests
python manage.py test
