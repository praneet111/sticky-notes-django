
from django.test import TestCase
from django.urls import reverse
from .models import Note

class NoteTests(TestCase):

    def test_create_note(self):
        note = Note.objects.create(title="Test", content="Content")
        self.assertEqual(note.title, "Test")

    def test_view_list(self):
        response = self.client.get(reverse('note_list'))
        self.assertEqual(response.status_code, 200)

    def test_create_view(self):
        response = self.client.post(reverse('note_create'), {
            'title': 'New',
            'content': 'Text'
        })
        self.assertEqual(response.status_code, 302)

    def test_delete(self):
        note = Note.objects.create(title="Delete", content="Me")
        response = self.client.post(reverse('note_delete', args=[note.id]))
        self.assertEqual(response.status_code, 302)
